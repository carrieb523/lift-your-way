LIFT YOUR WAY — PERSONAL WORKOUT APP TEST BUILD

Includes:
- Dark gym theme with black, charcoal, and green accents
- Strength workout builder by muscle group and equipment type
- Exercise library and add-your-own exercise
- Carries forward the last logged sets, reps, and weight for an exercise
- Edit those values before adding the exercise to the next workout
- Cardio logs with minutes, zone, effort, notes
- Weight, measurements, personal records, goals
- JSON export/import backup
- PWA manifest, icons, and offline shell

IMPORTANT:
- This is a test PWA, not yet hosted or published.
- Workout entries are stored in local browser storage on this device/browser.
- No login, cloud sync, secure photo storage, or App Store package yet.
- Export a backup regularly. Do not store sensitive medical information here.

TO INSTALL ON IPHONE:
1. Publish these files to an HTTPS web host (PWA installation needs a secure origin).
2. Open the published HTTPS URL in Safari on the iPhone.
3. Tap Share -> Add to Home Screen. If shown, enable Open as Web App, then tap Add.
4. Launch the new Home Screen icon.

Opening index.html directly from the ZIP is useful for a basic preview, but does not install the PWA. The service worker and offline behavior require HTTPS or localhost.

Next steps after test:
- Test workout carryover and all forms.
- Choose a hosting and private cloud database/authentication strategy for syncing.
- Consider native App Store packaging only after this version is proven useful.
